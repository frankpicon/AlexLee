﻿
using System.ComponentModel;
using System.Text;
using AlexLee.Screening.Models;


/*###############################################################################################################
1) Write a function that accepts two strings and produces an interleaved result composed of alternating
letters from each source string. Example,
Input string 1 - "abc" and string 2 "123", the output should be "a1b2c3".
###############################################################################################################*/

InterLeaveString interLeaveString = new InterLeaveString();
string inputString1 = "abc";
string inputString2 = "123";

string output = interLeaveString.Interleave(inputString1, inputString2);
Console.WriteLine($"1) Use Case 1 - Interleave String : System used 2 strings 'abc' and '123' and produced an interleaved result \n composed of alternating letters from each string. \n\n The output is the following: {output}");
Console.ReadLine();


/*###############################################################################################################
2) Find if the given string is a palindrome or not?
The user will input a string and program should print “Palindrome” or “Not Palindrome” based on
whether the input string is a palindrome or not.
    input: madam, output: Palindrome
    input: step on no pets, output: Palindrome
    input: book, output: Not Palindrome
if we pass an integer as a string parameter then also the program should give the correct output
input: 1221, output: Palindrome
###############################################################################################################*/
Palindrome palindrome = new Palindrome();
Console.WriteLine("2) Use Case 2: Palindrome : System will take a string or number and determine if it is a Palindrome. \n Please enter a string or number to determine if it is a Palindrome.");

string input = Console.ReadLine();

    if (palindrome.IsPalindrome(input))
    {
        Console.WriteLine("Palindrome");
    }
    else
    {
        Console.WriteLine("Not Palindrome");
    }

Console.ReadLine();


/*###############################################################################################################
3) Write a function that takes a source directory path, a search string, and a destination filename. The
function should then open all the files in the given directory in parallel (using parallelization technique
of your choice), find lines that have the search text in them, and extract and output all lines with that
search text in a file with the given destination filename. At the end of execution, the function should
output the number of files it processed, the number of lines it found the search text in, and the number
of occurrences of that search term (don't assume once per line).
###############################################################################################################*/

string sourceDirectory = "C:\\FP\\FPDocs\\FPTest";
string searchText = "frank";
string destinationFilename = "C:\\FP\\FPDocs\\FPTest\\output.txt";

await SearchTextInFilesAsync(sourceDirectory, searchText, destinationFilename);



static async Task SearchTextInFilesAsync(string sourceDirectory, string searchText, string destinationFilename)
{
    // Get all files in the source directory
    string[] files = Directory.GetFiles(sourceDirectory);

    // Initialize counters
    int filesProcessed = 0;
    int linesFound = 0;
    int occurrences = 0;

    // Process files asynchronously in parallel
    await Task.WhenAll(Array.ConvertAll(files, async file =>
    {
        try
        {
            using (FileStream stream = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read, bufferSize: 4096, useAsync: true))
            using (StreamReader reader = new StreamReader(stream))
            {
                string line;
                while ((line = await reader.ReadLineAsync()) != null)
                {
                    if (line.Contains(searchText))
                    {
                        linesFound++;
                        occurrences += CountOccurrences(line, searchText);

                        await WriteToFileAsync(destinationFilename, line + Environment.NewLine);
                    }
                }
            }

            filesProcessed++;
        }
        catch (IOException ex)
        {
            Console.WriteLine($"Error processing file: {ex.Message}");
        }
    }));

    // Output summary
    Console.WriteLine($"Number of files processed: {filesProcessed}");
    Console.WriteLine($"Number of lines found: {linesFound}");
    Console.WriteLine($"Number of occurrences of '{searchText}': {occurrences}");
}

static int CountOccurrences(string text, string searchTerm)
{
    int count = 0;
    int index = 0;
    while ((index = text.IndexOf(searchTerm, index, StringComparison.OrdinalIgnoreCase)) != -1)
    {
        index += searchTerm.Length;
        count++;
    }
    return count;
}

static async Task WriteToFileAsync(string filePath, string content)
{
    byte[] contentBytes = Encoding.UTF8.GetBytes(content);
    using (FileStream stream = new FileStream(filePath, FileMode.Append, FileAccess.Write, FileShare.Write, bufferSize: 4096, useAsync: true))
    {
        await stream.WriteAsync(contentBytes, 0, contentBytes.Length);
    }
}