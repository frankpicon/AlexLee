﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlexLee.Screening.Models
{
    /*###############################################################################################################
    1) Write a function that accepts two strings and produces an interleaved result composed of alternating
    letters from each source string. Example,
    Input string 1 - "abc" and string 2 "123", the output should be "a1b2c3".
    ###############################################################################################################*/
    public class InterLeaveString

    {
        public string Interleave(string string1, string string2)
        {
            int minLength = Math.Min(string1.Length, string2.Length);
            StringBuilder interleaved = new StringBuilder();

            // Zip the two strings together, then flatten the resulting sequence of pairs into a single string
            interleaved.Append(string.Concat(string1.Zip(string2, (c1, c2) => $"{c1}{c2}")));

            // Append remaining characters from the longer string
            interleaved.Append(string1.Substring(minLength)).Append(string2.Substring(minLength));

            return interleaved.ToString();
        }
    }

}
