﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlexLee.Screening.Models
{
/*###############################################################################################################
2) Find if the given string is a palindrome or not?
The user will input a string and program should print “Palindrome” or “Not Palindrome” based on
whether the input string is a palindrome or not.
    input: madam, output: Palindrome
    input: step on no pets, output: Palindrome
    input: book, output: Not Palindrome
if we pass an integer as a string parameter then also the program should give the correct output
input: 1221, output: Palindrome
###############################################################################################################*/

    public class Palindrome
    {
        public bool IsPalindrome(string str)
        {
            // Remove non-alphanumeric characters and convert to lowercase
            string cleanStr = new string(str.Where(char.IsLetterOrDigit).Select(char.ToLower).ToArray());

            // Compare the cleaned string with its reverse
            return cleanStr.SequenceEqual(cleanStr.Reverse());
        }
    }
}
