﻿using Microsoft.VisualStudio.TestPlatform.TestHost;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AlexLee.Screening.Models;

namespace AlexLee.ScreeningTests
{
    [TestClass]
    public class PalindromeTests
    {
        [DataTestMethod]
        [DataRow("madam", true)]
        [DataRow("step on no pets", true)]
        [DataRow("book", false)]
        [DataRow("1221", true)]
        [DataRow("A man, a plan, a canal, Panama", true)] // Test with non-alphanumeric characters and case-insensitivity
        [DataRow("racecar!", true)] // Test with non-alphanumeric characters
        public void IsPalindrome_ValidStrings_ReturnsCorrectResult(string input, bool expectedResult)
        {
            // Act

            bool result = new Palindrome().IsPalindrome(input);

            // Assert
            Assert.AreEqual(expectedResult, result);
        }
    }
}
