﻿using Microsoft.VisualStudio.TestPlatform.TestHost;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AlexLee.Screening.Models;
namespace Tests
{
    [TestClass()]
    public class InterLeaveStringTests
    {
        [TestMethod]
        public void InterleaveStrings_InputStrings_ReturnsInterleavedString()
        {
            // Arrange
            string inputString1 = "abc";
            string inputString2 = "123";
            string expectedOutput = "a1b2c3";

            // Act
            string output = new InterLeaveString().Interleave(inputString1, inputString2);

            // Assert
            Assert.AreEqual(expectedOutput, output);
        }

        [TestMethod]
        public void InterleaveStrings_InputStringsOfDifferentLengths_ReturnsInterleavedStringWithRemainingCharacters()
        {
            // Arrange
            string inputString1 = "abc";
            string inputString2 = "12345";
            string expectedOutput = "a1b2c345";

            // Act
            string output = new InterLeaveString().Interleave(inputString1, inputString2);

            // Assert
            Assert.AreEqual(expectedOutput, output);
        }

        [TestMethod]
        public void InterleaveStrings_EmptyInputStrings_ReturnsEmptyString()
        {
            // Arrange
            string inputString1 = "";
            string inputString2 = "";
            string expectedOutput = "";

            // Act
            string output = new InterLeaveString().Interleave(inputString1, inputString2);

            // Assert
            Assert.AreEqual(expectedOutput, output);
        }
    }
}